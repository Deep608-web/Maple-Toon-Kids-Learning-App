package com.mapletoonkids.learning;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import android.speech.tts.Voice;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadsImagesAutomatically(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new TTSBridge(), "AndroidTTS");

        initTts();
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;

            tts.setLanguage(Locale.US);
            tts.setSpeechRate(0.90f);
            tts.setPitch(1.02f);

            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    List<Voice> english = new ArrayList<>();
                    for (Voice v : voices) {
                        if (v.getLocale() != null && "en".equals(v.getLocale().getLanguage())) {
                            english.add(v);
                        }
                    }
                    english.sort(Comparator
                        .comparingInt(Voice::getQuality).reversed()
                        .thenComparingInt(Voice::getLatency));
                    if (!english.isEmpty()) tts.setVoice(english.get(0));
                }
            } catch (Exception ignored) {}

            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {
                    mainHandler.post(() ->
                        webView.evaluateJavascript("window.__androidTtsStart&&window.__androidTtsStart()", null));
                }
                @Override public void onDone(String utteranceId) {
                    mainHandler.post(() ->
                        webView.evaluateJavascript("window.__androidTtsEnd&&window.__androidTtsEnd()", null));
                }
                @Override public void onError(String utteranceId) {
                    mainHandler.post(() ->
                        webView.evaluateJavascript("window.__androidTtsEnd&&window.__androidTtsEnd()", null));
                }
            });
        });
    }

    private class TTSBridge {
        @JavascriptInterface
        public void speak(String text) {
            mainHandler.post(() -> {
                if (tts == null || text == null || text.trim().isEmpty()) return;
                tts.stop();
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null,
                    "maple_" + System.currentTimeMillis());
            });
        }

        @JavascriptInterface
        public void stop() {
            mainHandler.post(() -> {
                if (tts != null) tts.stop();
                webView.evaluateJavascript("window.__androidTtsEnd&&window.__androidTtsEnd()", null);
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // Prevent accidental exit during long live playback.
        if (webView != null && webView.canGoBack()) webView.goBack();
    }
}
