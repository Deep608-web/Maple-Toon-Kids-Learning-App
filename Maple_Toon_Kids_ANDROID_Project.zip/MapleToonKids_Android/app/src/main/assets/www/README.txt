Maple Toon Kids Learning Adventure V7 — Stable Character Build

Fixes:
- Teacher states are PRELOADED as three layered images (normal, blink, talk), so no repeated image loading/flicker.
- Eye blink runs automatically every few seconds.
- Talking mouth toggles only while voiceover is speaking.
- Teacher remains seated and uses the same beige blazer / white blouse / navy skirt look.
- Exact user-provided Maple Toon Kids logo is used with the checkerboard background removed.
- MAPLE letters pulse one-by-one in a continuous loop.
- Countdown and reward SFX remain enabled.
- Service worker is disabled for local file:// opening to avoid stale-cache issues.
