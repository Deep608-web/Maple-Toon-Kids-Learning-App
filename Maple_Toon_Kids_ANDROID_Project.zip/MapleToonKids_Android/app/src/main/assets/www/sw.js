const CACHE='maple-learning-v2';
const FILES=['./','./index.html','./manifest.json','./assets/icon-512.png','./assets/teacher_front.png','./assets/teacher_right3q.png','./assets/teacher_left3q.png','./assets/cat.jpg','./assets/dog.jpg','./assets/rabbit.jpg','./assets/apple.jpg','./assets/banana.jpg','./assets/orange.jpg','./assets/bg_garden.jpg','./assets/bg_playroom.jpg','./assets/bg_classroom.jpg','./assets/bg_garden_alt.jpg','./assets/bg_playroom_alt.jpg','./assets/bg_classroom_alt.jpg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
