MAPLE TOON KIDS LEARNING — ANDROID PROJECT

This is a native Android WebView application project.
App ID: com.mapletoonkids.learning
Orientation: Landscape
Minimum Android: Android 7.0 (API 24)

Important Android-specific improvements:
• Keeps the screen awake for long live playback.
• Runs full-screen landscape.
• Loads all lesson files locally from the APK.
• Uses Android TextToSpeech through a native bridge when available.
• Teacher speaking animation follows Android TTS start/end.
• Tapping answers remains optional; lessons autoplay.

TO BUILD WITH ANDROID STUDIO:
1. Open this folder as a project.
2. Allow Gradle sync to complete.
3. Build > Build APK(s).
4. APK appears under app/build/outputs/apk/debug/app-debug.apk.

A GitHub Actions workflow is also included at:
.github/workflows/build-apk.yml
It automatically creates the debug APK when the project is pushed to GitHub.
